# مجلة راية المستقبل — Raya Future Magazine

موقع مجلة طلابية إلكترونية بُني بـ Next.js 16 + TypeScript + Tailwind CSS 4.

## التشغيل

```bash
npm install
npm run dev
```

افتح المتصفح على: http://localhost:3000

## المتطلبات
- Node.js 18+
- npm 9+
